function startTests() {
	runSuite(0);
	
  	function runSuite(i) {
  		if (!suites[i])
  			return;
		var iframe = document.createElement('iframe');
		iframe.id = 'iframe' + i;
		iframe.src = suites[i] + '/suite.html';
		iframe.scrolling = 'no';
		iframe.width = '100%';
		iframe.addEventListener('load', checkForTestCompletion);
		document.body.appendChild(iframe);
			
  		function checkForTestCompletion() {
  			var passedCountEl = iframe.contentWindow.document.getElementById('passedCount');
  			if (!passedCountEl) {
	  			setTimeout(checkForTestCompletion, 1);
  			} else {
  				var iframeDoc = iframe.contentWindow.document;
  				iframeDoc.body.insertBefore(getSuiteHeader(iframe), iframeDoc.body.childNodes[0]);
  				
  				var passedCount = passedCountEl.innerHTML;
  				var totalCount = iframeDoc.getElementById('specCount').innerHTML;
  				var row = document.getElementById('testResultSummary').insertRow(-1);
  				var cell1 = row.insertCell(0);
  				cell1.innerHTML = getSuiteLink(iframe, passedCount, totalCount);
  				var cell2 = row.insertCell(1);
  				cell2.innerHTML = passedCountEl.innerHTML + '/' + totalCount + ' passed';
  				iframe.style.height = iframeDoc.body.scrollHeight + 10 + 'px';
  				runSuite(++i);
	  		}
  		}
 	}
  	
  	function getSuiteHeader(iframe) {
  		var a = document.createElement('a');
		a.appendChild(document.createTextNode('> ' + iframe.contentWindow.document.title));
		a.href = '#';
		a.setAttribute('style', 'color: green');
		a.addEventListener('click', function() {
			window.top.location.href = iframe.src;
		});
		return a;
  	}
 	
 	function getSuiteLink(iframe, passedCount, totalCount) {
 		var color = passedCount == totalCount ? 'green' : 'red';
 		return '<a href=\'#' + iframe.id + '\' style=\'color: ' + color + '\'>' + iframe.contentWindow.document.title + '</a>';
 	}
}