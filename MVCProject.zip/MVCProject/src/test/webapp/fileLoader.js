var thisScriptLocation = document.getElementsByTagName('script')[0].src;
var projectPath = thisScriptLocation.substring(0, thisScriptLocation.indexOf('src'));
var testPrefix = projectPath + 'src/test/webapp/';
var sourcePrefix = projectPath + 'src/main/webapp/';

loadCSS(testPrefix + 'lib/jasmine/jasmine.css');
loadJS(testPrefix + 'lib/jasmine/jasmine.js');
loadJS(testPrefix + 'lib/jasmine/jasmine-html.js');
loadJS(testPrefix + 'lib/jasmine/jasmine-custom.js');

function loadCSS(filePath) {
	var css = document.createElement('link');
	css.setAttribute('rel', 'stylesheet');
	css.setAttribute('type', 'text/css');
	css.setAttribute('href', filePath);
	document.head.appendChild(css);
}

function loadJS(filePath) {
	var js = document.createElement('script');
	js.setAttribute('type', 'text/javascript');
	js.setAttribute('src', filePath);
	document.head.appendChild(js);
}

function loadSource(filePath) {
	loadJS(sourcePrefix + filePath);
}