describe('PersonnelModel', function() {
	test('constants', function() {
		expect(PersonnelModel.FIRST_NAME).toEqual('firstName');
		expect(PersonnelModel.LAST_NAME).toEqual('lastName');
		expect(PersonnelModel.TEAM).toEqual('team');
	});
	test('fields default to empty', function() {
		var model = new PersonnelModel();
		expect(model[PersonnelModel.FIRST_NAME]).toEqual('');
		expect(model[PersonnelModel.LAST_NAME]).toEqual('');
		expect(model[PersonnelModel.TEAM]).toEqual('');
	});
});