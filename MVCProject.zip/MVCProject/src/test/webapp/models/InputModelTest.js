describe('InputModel', function() {
	test('constructor with no args', function() {
		var model = new InputModel();
		expect(model.wrapper).toEqual({});
		expect(model.valueField).toEqual('value');
	});
	test('constructor with args', function() {
		var wrapper = {};
		var model = new InputModel(wrapper, 'testField');
		expect(model.wrapper).toBe(wrapper);
		expect(model.valueField).toEqual('testField');
	});
	test('getValue when undefined', function() {
		var model = new InputModel();
		expect(model.getValue()).toEqual('');
	});
	test('getValue when null', function() {
		var model = new InputModel({testField: null}, 'testField');
		expect(model.getValue()).toEqual('');
	});
	test('getValue when not null', function() {
		var model = new InputModel({testField: 'testValue'}, 'testField');
		expect(model.getValue()).toEqual('testValue');
	});
	test('setValue', function() {
		var wrapper = {};
		var model = new InputModel(wrapper, 'testField');
		model.setValue('testValue');
		expect(wrapper.testField).toEqual('testValue');
	});
});