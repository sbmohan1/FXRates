describe('PersonnelStoreModel', function() {
	test('constructor sets up store', function() {
		var results = ['result1'];
		PersonnelService.search.andReturn(results);
		var model = new PersonnelStoreModel();
		expect(PersonnelService.search).toHaveBeenCalled();
		expect(model.store).toBe(results);
	});
});