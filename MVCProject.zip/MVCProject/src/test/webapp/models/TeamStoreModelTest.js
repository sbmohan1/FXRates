describe('TeamStoreModel', function() {
	test('constructor sets up store', function() {
		var teams = ['team1'];
		PersonnelService.getTeams.andReturn(teams);
		var model = new TeamStoreModel();
		expect(PersonnelService.getTeams).toHaveBeenCalled();
		expect(model.store).toBe(teams);
	});
});