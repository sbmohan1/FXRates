describe('FormModel', function() {
	test('fields default to empty/null', function() {
		var model = new FormModel();
		expect(model[PersonnelModel.FIRST_NAME]).toEqual('');
		expect(model[PersonnelModel.LAST_NAME]).toEqual('');
		expect(model[PersonnelModel.TEAM]).toEqual('');
		expect(model.selectedCriterion).toBe(null);
	});
});