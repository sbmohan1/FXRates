describe('StoreModel', function() {
	var store = ['test'];
	test('storeProxy returns empty array', function() {
		var model = new StoreModel();
		expect(model.storeProxy()).toEqual([]);
	});
	test('refresh calls proxy and saves to store', function() {
		StoreModel.prototype.storeProxy = jasmine.createSpy('proxy').andReturn(store);
		var model = new StoreModel();
		model.store = null;
		model.refresh();
		expect(model.storeProxy).toHaveBeenCalled();
		expect(model.store).toBe(store);
	});
	test('constructor sets up store', function() {
		var model = new StoreModel();
		expect(model.store).toEqual(store);
	});
});