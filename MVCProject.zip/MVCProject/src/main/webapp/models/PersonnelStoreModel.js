function PersonnelStoreModel(form) {
	this.form = form;
	StoreModel.call(this);
}

PersonnelStoreModel.prototype = Object.create(StoreModel.prototype);
PersonnelStoreModel.prototype.storeProxy = function() {
	return PersonnelService.search(this.form);
};