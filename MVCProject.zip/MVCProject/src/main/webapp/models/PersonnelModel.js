function PersonnelModel() {
	this[PersonnelModel.FIRST_NAME] = '';
	this[PersonnelModel.LAST_NAME] = '';
	this[PersonnelModel.TEAM] = '';
}

PersonnelModel.FIRST_NAME = 'firstName';
PersonnelModel.LAST_NAME = 'lastName';
PersonnelModel.TEAM = 'team';