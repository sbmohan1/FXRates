function StoreModel() {
	this.refresh();
}

StoreModel.prototype = {
	refresh: function() {
		this.store = this.storeProxy();
	},
	storeProxy: function() {
		return [];
	}
};