function FormModel() {
	PersonnelModel.call(this);
	this.selectedCriterion = null;
}