function TeamStoreModel() {
	StoreModel.call(this);
}

TeamStoreModel.prototype = Object.create(StoreModel.prototype);
TeamStoreModel.prototype.storeProxy = PersonnelService.getTeams;