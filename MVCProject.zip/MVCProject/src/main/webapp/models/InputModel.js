function InputModel(wrapper, valueField) {
	this.wrapper = wrapper || {};
	this.valueField = valueField || 'value';
}

InputModel.prototype = {
	getValue: function() {
		return this.wrapper[this.valueField] || '';
	},
	setValue: function(value) {
		this.wrapper[this.valueField] = value;
	}
};