function ResultsTableController(view, model) {
	this.view = view;
	this.model = model;
	this.init();
}

ResultsTableController.prototype = {
	init: function() {
		this.loadResults();
	},
	loadResults: function() {
		this.view.generateRows(this.model.store.length);
		for (var i in this.model.store) {
			new PersonnelController(this.view.rows[i], this.model.store[i]);
		}
	}
};

ResultsTableController.init = function(form) {
	new ResultsTableController(new ResultsTable(), new PersonnelStoreModel(form));
};