function PersonnelController(view, model) {
	this.view = view;
	this.model = model;
	this.init();
}

PersonnelController.prototype = {
	init: function() {
		this.bindData();
	},
	bindData: function() {
		new InputController(this.view.cells[0].element, new InputModel(this.model, PersonnelModel.FIRST_NAME));
		new InputController(this.view.cells[1].element, new InputModel(this.model, PersonnelModel.LAST_NAME));
		new SelectInputController(this.view.cells[2].element, new InputModel(this.model, PersonnelModel.TEAM)).loadStore(new TeamStoreModel());
	}
};