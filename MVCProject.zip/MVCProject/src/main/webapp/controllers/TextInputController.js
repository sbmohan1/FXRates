function TextInputController(view, model) {
	InputController.call(this, view, model);
	this.setChangeListener();
}

TextInputController.prototype = Object.create(InputController.prototype);
TextInputController.prototype.setChangeListener = function() {
	var model = this.model;
	this.view.domEl.oninput = function() {
		model.setValue(this.value);
	};
};