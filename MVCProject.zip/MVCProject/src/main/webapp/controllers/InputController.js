function InputController(view, model) {
	this.view = view;
	this.model = model;
	this.syncValue();
}

InputController.prototype = {
	syncValue: function() {
		this.view.setValue(this.model.getValue());
	}
};