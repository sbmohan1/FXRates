function FormController(view, model) {
	this.view = view;
	this.model = model;
	this.init();
}

FormController.prototype = {
	init: function() {
		this.setUpInputs();
		this.setRadioListeners();
		this.setSubmitListener();
	},
	setUpInputs: function() {
		new TextInputController(this.view.inputs.firstName, new InputModel(this.model, PersonnelModel.FIRST_NAME));
		new TextInputController(this.view.inputs.lastName, new InputModel(this.model, PersonnelModel.LAST_NAME));
		new SelectInputController(this.view.inputs.team, new InputModel(this.model, PersonnelModel.TEAM)).loadStore(new TeamStoreModel());
	},
	setRadioListeners: function() {
		var view = this.view;
		var model = this.model;
		
		this.view.radios.firstName.domEl.onclick = function() {
			selectInput.call(view.inputs.firstName, PersonnelModel.FIRST_NAME);
		};
		this.view.radios.lastName.domEl.onclick = function() {
			selectInput.call(view.inputs.lastName, PersonnelModel.LAST_NAME);
		};
		this.view.radios.team.domEl.onclick = function() {
			selectInput.call(view.inputs.team, PersonnelModel.TEAM);
		};
		this.view.radios.firstName.domEl.click();
		
		function selectInput(inputName) {
			view.disableAll();
			this.setDisabled(false);
			model.selectedCriterion = inputName;
		}
	},
	setSubmitListener: function() {
		var me = this;
		this.view.submitButton.domEl.onclick = function() {
			ResultsTableController.init(me.model);
		};
	}
};

FormController.init = function() {
	new FormController(new Form(), new FormModel());
};