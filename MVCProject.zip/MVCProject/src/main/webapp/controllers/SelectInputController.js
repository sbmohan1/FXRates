function SelectInputController(view, model) {
	InputController.call(this, view, model);
	this.setChangeListener();
}

SelectInputController.prototype = Object.create(InputController.prototype);
SelectInputController.prototype.setChangeListener = function() {
	var model = this.model;
	this.view.domEl.onchange = function() {
		model.setValue(this.value);
	};
};
SelectInputController.prototype.loadStore = function(storeModel) {
	this.view.loadOptions(storeModel.store);
	var me = this;
	setTimeout(function() {
		me.syncValue();
	}, 1);
};