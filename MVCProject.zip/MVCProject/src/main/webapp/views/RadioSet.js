function RadioSet(name, values) {
	for (var i in values) {
		var value = values[i];
		this[value] = new Radio(value + '-radio', name, value);
	}
}