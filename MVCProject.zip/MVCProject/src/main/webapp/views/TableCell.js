function TableCell(columnConfig) {
	Element.call(this);
	var ElementType = columnConfig.elementType || Span;
	this.element = new ElementType();
	this.domEl.appendChild(this.element.domEl);
}

TableCell.prototype.htmlType = 'td';