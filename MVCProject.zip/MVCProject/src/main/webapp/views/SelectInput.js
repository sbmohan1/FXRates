function SelectInput(id) {
	Element.call(this, id);
}

SelectInput.prototype = {
	htmlType: 'select',
	setValue: function(value) {
		this.domEl.value = value;
		if (this.domEl.onchange)
			this.domEl.onchange();
	},
	setDisabled: function(disabled) {
		this.domEl.disabled = disabled;
	},
	loadOptions: function(options) {
		if (!options)
			return;
		for (var i in options) {
			var option = options[i];
			var optionEl = document.createElement('option');
			optionEl.value = option;
			optionEl.innerHTML = option;
			this.domEl.appendChild(optionEl);
		}
	}
};