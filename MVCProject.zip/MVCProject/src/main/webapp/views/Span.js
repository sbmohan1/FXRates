function Span(id) {
	Element.call(this, id);
}

Span.prototype = {
	htmlType: 'span',
	setValue: function(value) {
		this.domEl.innerHTML = value;
	}
};