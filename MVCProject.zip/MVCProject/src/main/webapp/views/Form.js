function Form() {
	this.radios = new RadioSet('radioMenu', ['firstName', 'lastName', 'team']);
	this.inputs = {
		firstName: new TextInput('firstName-input'),
		lastName: new TextInput('lastName-input'),
		team: new SelectInput('team-input')
	};
	this.submitButton = new Button('submit');
}

Form.prototype = {
	disableAll: function() {
		for (var i in this.inputs)
			this.inputs[i].setDisabled(true);
	}
};