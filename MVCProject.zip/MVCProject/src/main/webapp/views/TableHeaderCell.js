function TableHeaderCell(columnConfig) {
	Element.call(this);
	this.domEl.innerHTML = columnConfig.label;
	this.domEl.width = columnConfig.width;
}

TableHeaderCell.prototype.htmlType = 'th';