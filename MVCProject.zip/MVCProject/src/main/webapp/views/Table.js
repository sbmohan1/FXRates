function Table(id, columns) {
	Element.call(this, id);
	this.columns = columns;
	this.headerRow = new TableRow(TableHeaderCell, columns);
	this.rows = [];
	this.domEl.innerHTML = '';
	this.domEl.appendChild(this.headerRow.domEl);
}

Table.prototype = {
	htmlType: 'table',
	generateRows: function(rows) {
		this.rows = [];
		while (this.domEl.childNodes.length > 1)
			this.domEl.removeChild(this.domEl.lastChild);
		for (var i = 0; i < rows; i++)
			this.addRow();
	},
	addRow: function() {
		var row = new TableRow(TableCell, this.columns);
		this.rows.push(row);
		this.domEl.appendChild(row.domEl);
	}
};