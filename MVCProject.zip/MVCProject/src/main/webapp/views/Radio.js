function Radio(id, name, value) {
	Element.call(this, id);
	this.domEl.name = name;
	this.domEl.value = value;
}

Radio.prototype = {
	htmlType: 'input',
	htmlAttributes: {
		type: 'radio'
	}
};