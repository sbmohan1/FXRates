function Button(id, text) {
	Element.call(this, id);
	if (text)
		this.domEl.value = text;
}

Button.prototype = {
	htmlType: 'input',
	htmlAttributes: {
		type: 'button'
	}
};