function TextInput(id) {
	Element.call(this, id);
}

TextInput.prototype = {
	htmlType: 'input',
	htmlAttributes: {
		type: 'text'
	},
	setValue: function(value) {
		this.domEl.value = value;
		if (this.domEl.oninput)
			this.domEl.oninput();
	},
	setDisabled: function(disabled) {
		this.domEl.disabled = disabled;
	}
};