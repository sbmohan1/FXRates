function Element(id) {
	if (id)
		this.domEl = document.getElementById(id);
	if (!this.domEl) {
		this.domEl = document.createElement(this.htmlType);
		this.domEl.id = id;
	}
	for (var attr in this.htmlAttributes)
		this.domEl[attr] = this.htmlAttributes[attr];
}