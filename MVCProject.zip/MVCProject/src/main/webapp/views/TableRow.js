function TableRow(CellType, columns) {
	Element.call(this);
	this.cells = [];
	for (var i in columns) {
		var cell = new CellType(columns[i]);
		this.cells.push(cell);
		this.domEl.appendChild(cell.domEl);
	}
}

TableRow.prototype.htmlType = 'tr';