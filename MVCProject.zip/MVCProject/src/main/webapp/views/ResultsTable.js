function ResultsTable() {
	return new Table('results', [
		{label: 'First Name', width: '100'},
		{label: 'Last Name', width: '125'},
		{label: 'Department', width: '100', elementType: SelectInput}
	]);
}