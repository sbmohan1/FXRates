var PersonnelService = {
	getTeams: function() {
		return [
	        'Avengers',
	        'Rocket Tech',
	        'Na Fianna',
	        'Studio Ghibli',
	        'Phantom Troupe',
	        'Ginyu Force',
	        'Team 64',
	        'BA'
        ];
	},
	search: function(form) {
		var results = [];
		var fieldToMatch = form.selectedCriterion;
		var valueToMatch = form[fieldToMatch];
		for (var i in PersonnelDirectory) {
			var personnel = PersonnelDirectory[i];
			if (new RegExp(valueToMatch, 'i').exec(personnel[fieldToMatch]))
				results.push(personnel);
		}
		return results;
	}
};