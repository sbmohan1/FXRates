var PersonnelDirectory = [
	{
		id: 0,
		firstName: 'Yann',
		lastName: 'Le Roux',
		currentEmployee: true
	},
	{
		id: 1,
		firstName: 'Martin',
		lastName: 'Gillin',
		currentEmployee: true
	},
	{
		id: 2,
		firstName: 'Robert',
		lastName: 'Delaney',
		nickname: 'Rob',
		college: 'Cornell',
		currentEmployee: true
	},
	{
		id: 3,
		firstName: 'John',
		lastName: 'Hutton',
		nickname: 'Jack',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 4,
		firstName: 'Sing Sing',
		lastName: 'Ma',
		team: 'Avengers',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 5,
		firstName: 'Mina',
		lastName: 'Yamada',
		team: 'Avengers',
		currentEmployee: true
	},
	{
		id: 6,
		firstName: 'Kovey',
		lastName: 'Coles',
		team: 'Avengers',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 7,
		firstName: 'Ismael',
		lastName: 'Catovic',
		team: 'Avengers',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 8,
		firstName: 'Xia',
		lastName: 'Deng',
		nickname: 'Summer',
		team: 'Avengers',
		college: 'Penn',
		currentEmployee: true
	},
	{
		id: 9,
		firstName: 'Andrew',
		lastName: 'Ardito',
		nickname: 'Drew',
		team: 'Rocket Tech',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 10,
		firstName: 'Patrick',
		lastName: 'Thompson',
		team: 'Rocket Tech',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 11,
		firstName: 'Raghu',
		lastName: 'Kanduru',
		team: 'Rocket Tech',
		currentEmployee: true
	},
	{
		id: 12,
		firstName: 'Mogileeswar',
		lastName: 'Gorrepati',
		nickname: 'Mogi',
		team: 'Rocket Tech',
		currentEmployee: true
	},
	{
		id: 13,
		firstName: 'Heling',
		lastName: 'Zhao',
		team: 'Rocket Tech',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 14,
		firstName: 'Weier',
		lastName: 'Chen',
		team: 'Rocket Tech',
		college: 'Cornell',
		currentEmployee: true
	},
	{
		id: 15,
		firstName: 'John',
		lastName: 'Timoney-Gomez',
		team: 'Studio Ghibli',
		college: 'Columbia',
		currentEmployee: true
	},
	{
		id: 16,
		firstName: 'Sarba',
		lastName: 'Bartaula',
		team: 'Studio Ghibli',
		college: 'Columbia',
		currentEmployee: true
	},
	{
		id: 17,
		firstName: 'Spandan',
		lastName: 'Das',
		team: 'Phantom Troupe',
		college: 'Cornell',
		currentEmployee: true
	},
	{
		id: 18,
		firstName: 'Kevin',
		lastName: 'Griffin',
		team: 'Na Fianna',
		currentEmployee: true
	},
	{
		id: 19,
		firstName: 'Peter',
		lastName: 'McGill',
		team: 'Na Fianna',
		currentEmployee: true
	},
	{
		id: 20,
		firstName: 'Glen',
		lastName: 'McCarthy',
		team: 'Na Fianna',
		currentEmployee: true
	},
	{
		id: 21,
		firstName: 'Viviana',
		lastName: 'Mardones',
		team: 'BA',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 22,
		firstName: 'Helen',
		lastName: 'Wong',
		team: 'BA',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 23,
		firstName: 'Jiawen',
		lastName: 'Li',
		team: 'BA',
		college: 'Penn',
		currentEmployee: true
	},
	{
		id: 24,
		firstName: 'Alexandra',
		lastName: 'Erixxon',
		nickname: 'Allie',
		team: 'BA',
		college: 'MIT',
		currentEmployee: true
	},
	{
		id: 25,
		firstName: 'Diego',
		lastName: 'Paris',
		team: 'Team 64',
		college: 'Columbia',
		currentEmployee: true
	},
	{
		id: 26,
		firstName: 'Minhaz',
		lastName: 'Mahbub',
		team: 'Team 64',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 27,
		firstName: 'Megan',
		lastName: 'Dare',
		team: 'Team 64',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 28,
		firstName: 'Andre',
		lastName: 'Pavia',
		team: 'Team 64',
		currentEmployee: true
	},
	{
		id: 29,
		firstName: 'Wei',
		lastName: 'Chen',
		team: 'Rocket Tech',
		college: 'Penn',
		currentEmployee: true
	},
	{
		id: 30,
		firstName: 'Ingrid',
		lastName: 'Yen',
		team: 'Rocket Tech',
		currentEmployee: true
	},
	{
		id: 31,
		firstName: 'Rafael',
		lastName: 'Grillo Avila',
		team: 'Rocket Tech',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 32,
		firstName: 'Kenneth',
		lastName: 'Wong',
		nickname: 'Kenny',
		team: 'Studio Ghibli',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 33,
		firstName: 'Melissa',
		lastName: 'Seto',
		team: 'Studio Ghibli',
		college: 'Columbia',
		currentEmployee: true
	},
	{
		id: 34,
		firstName: 'Parker',
		lastName: 'Oka-Wong',
		team: 'Phantom Troupe',
		college: 'Columbia',
		currentEmployee: true
	},
	{
		id: 35,
		firstName: 'Paimon',
		lastName: 'Pakzad',
		team: 'Phantom Troupe',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 36,
		firstName: 'Angela',
		lastName: 'Malouf',
		nickname: 'Miyo',
		team: 'BA',
		college: 'Brown',
		currentEmployee: true
	},
	{
		id: 37,
		firstName: 'Dana',
		lastName: 'Ramirez',
		team: 'BA',
		college: 'Princeton',
		currentEmployee: true
	},
	{
		id: 38,
		firstName: 'Shane',
		lastName: 'McCarthy',
		team: 'Na Fianna',
		currentEmployee: true
	},
	{
		id: 39,
		firstName: 'Raymond',
		lastName: 'Allen',
		nickname: 'Ray',
		team: 'Na Fianna',
		currentEmployee: true
	},
	{
		id: 40,
		firstName: 'Jae',
		lastName: 'Chung',
		team: 'Ginyu Force',
		currentEmployee: true
	},
	{
		id: 41,
		firstName: 'Eric',
		lastName: 'Keehn',
		team: 'Ginyu Force',
		currentEmployee: true
	},
	{
		id: 42,
		firstName: 'Mandy',
		lastName: 'Ng',
		team: 'Ginyu Force',
		currentEmployee: true
	},
	{
		id: 43,
		firstName: 'Paul',
		lastName: 'Ferker',
		team: 'Ginyu Force',
		currentEmployee: true
	},
	{
		id: 44,
		firstName: 'Sridhar',
		lastName: 'Subramanian',
		nickname: 'Sri',
		team: 'Ginyu Force',
		currentEmployee: true
	},
	{
		id: 45,
		firstName: 'Justin',
		lastName: 'George',
		currentEmployee: true
	},
	{
		id: 46,
		firstName: 'Timothy',
		lastName: 'Delaney',
		nickname: 'Tim',
		college: 'Penn',
		currentEmployee: false
	}
];