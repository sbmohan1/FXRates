function updateDisplay() {

	var selectedCurrency = document.getElementById("selectedCurrency").value;

	for ( var i in currencies) {
		if (oldCurrency != selectedCurrency
				&& currencies[i] == selectedCurrency) {
			document.getElementById(currencies[i]).style.display = "";
			oldCurrency = selectedCurrency;
		} else {
			document.getElementById(currencies[i]).style.display = "none";
		}
	}
	document.getElementById("selectedCurrency").value = "DEF";
}