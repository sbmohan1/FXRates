function loadDisplay() {
	
	document.getElementById("INR").style.display = "none";
	document.getElementById("AUD").style.display = "none";
	document.getElementById("CAD").style.display = "none";
	document.getElementById("ZAR").style.display = "none";
	document.getElementById("NZD").style.display = "none";
	document.getElementById("JPY").style.display = "none";
	
}