package training.web.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/HelloWorld")
public class HelloWorldController {
	
	@RequestMapping(value = "hello", method = RequestMethod.GET, produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> helloWorld()	{
		return new ResponseEntity<String>("Hello World!!!", HttpStatus.OK);
	}
	
	@RequestMapping(value = "hello/{name}", method = RequestMethod.GET, produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> helloWorld(@PathVariable("name") String name)	{
		return new ResponseEntity<String>("Hello " + name + "!!!", HttpStatus.OK);
	}
	
	@RequestMapping(value = "user/{username}", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> getUser(@PathVariable("username") String username)	{
		User user = new User();
		user.setUsername(username);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
}
