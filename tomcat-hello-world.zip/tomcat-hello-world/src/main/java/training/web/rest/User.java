package training.web.rest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlRootElement(name = "user")
public class User {

	private String username;
	private String first_name;
	private String last_name;

	@XmlElement(name = "username")
	@JsonProperty(value = "username")
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@XmlElement(name = "firstName")
	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	@XmlElement(name = "lastName")
	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	
	@Override
	public String toString()	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("User: ").append(username).append("\n");
		return stringBuilder.toString();
	}

	
}
