package training.web.rest;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class TrainingRestClient {

	public static void main(String[] args) {
		if (args != null && args.length > 0 && args[0] != null) {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<User> response = restTemplate.exchange(
					"http://localhost:8080/tomcat-hello-world/rest/HelloWold/user", HttpMethod.GET, null, User.class,
					args[0]);
			if (response != null && HttpStatus.OK.equals(response.getStatusCode())) {
				System.out.println("Recieved a user with status OK(200)");
				User user = response.getBody();
				if (user != null) {
					System.out.println(user.toString());
				} else {
					System.out.println("No user found with username " + args[0]);
				}
			} else {
				System.err.println("An unexpected error happened.");
			}
		} else {
			System.err.println("You must provide a username.");
		}
	}

}
